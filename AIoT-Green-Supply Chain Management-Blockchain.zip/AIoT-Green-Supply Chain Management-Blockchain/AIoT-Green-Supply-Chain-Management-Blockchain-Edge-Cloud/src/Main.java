
import java.io.IOException;

public class Main {

    public static void main(String[] args) {
        SupplyChainSystem scs = new SupplyChainSystem();

        try {
            scs.loadData("Supply-chain.txt");
            scs.optimizeAndAnalyze();
            if (scs.validateBlockchain()) {
                System.out.println("Blockchain is valid.");
            } else {
                System.out.println("Blockchain is invalid.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
